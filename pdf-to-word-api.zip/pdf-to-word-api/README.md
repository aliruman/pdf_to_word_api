# PDF to Word API

This is a simple FastAPI application that converts base64-encoded PDF files into DOCX format and returns the result as a base64-encoded DOCX file.

## Deployment
Deploy it to Render, Railway, or any serverless Python platform.
